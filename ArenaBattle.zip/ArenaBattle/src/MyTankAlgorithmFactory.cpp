#include "MyTankAlgorithmFactory.h"
// #include "AggressiveTank.h"
// #include "EvasiveTank.h"
// #include  "common/TankAlgorithm.h"
// namespace common {

// std::unique_ptr<common::TankAlgorithm>
// MyTankAlgorithmFactory::create(int playerIndex, int tankIndex) const {
//     if (playerIndex == 1) {
//         // AggressiveTank derives from common::TankAlgorithm
//         return std::make_unique<arena::AggressiveTank>(playerIndex, tankIndex);
//     } else {
//         // EvasiveTank derives from common::TankAlgorithm
//         return std::make_unique<arena::EvasiveTank>(playerIndex, tankIndex);
//     }
// };

// } // namespace common
