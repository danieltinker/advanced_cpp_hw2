#include "MySatelliteView.h"

namespace arena {

MySatelliteView::MySatelliteView(const MyBattleInfo& battleInfo)
    : info_(battleInfo)
{}

char MySatelliteView::getObjectAt(size_t x, size_t y) const {
    return info_.getObjectAt(x, y);
}

} // namespace arena
