#include "MyBattleInfo.h"

namespace arena {
//TODO: fix logic
// MyBattleInfo::MyBattleInfo(std::size_t r, std::size_t c)
//   : rows(r), cols(c), grid(r, std::vector<char>(c, ' '))
// {}

void MyBattleInfo::setObjectAt(size_t x, size_t y, char c) {
    if (x < rows && y < cols) {
        grid[x][y] = c;
    }
}

char MyBattleInfo::getObjectAt(size_t x, size_t y) const {
    if (x < rows && y < cols) {
        return grid[x][y];
    }
    return '&'; // outside battlefield
}

} // namespace arena
