#include "Projectile.h"

// Everything is inline in the header (advance() is implemented there).
