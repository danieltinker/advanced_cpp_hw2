#include "utils.h"
// (Empty; all implementations are inline.)
